# Better-GUIlds
MAKE SURE YOU RUN THIS PROGRAM IN FULLSCREEN







1)Set up the Anaconda prompt as seen in steps 1-3 here: https://docs.google.com/document/d/1NEGeA6ZXVZtxUpOV9Y9YWCi8SSpugYmr9qDOCBLfDJM/edit#heading=h.hs65dkkf0u4t

2)Once you have Python Kivy and the Anaconda prompt  installed, please click this link to access our code repository: https://github.com/skyeeey/Better-GUIlds/tree/main

3)Please click on the dropdown “<> Code” and click on “Download ZIP”

4)Go to your Download section in your File Explorer and click on Downloads. You will see a zipped folder “Better-GUIlds-main”

5)Right-click on the folder “Better-GUIlds-main” and click “Extract All...” to unzip the folder.
In the box that says “Files will be extracted to this folder”, please redirect the folder to be in your Desktop section. Then, click “Extract”.
Example: If you downloaded the zipped folder, it will be in “C:\Users\ProfileName\Downloads\Better-GUIlds-main’. Please direct the unzipped folder to “C:\Users\ProfileName\Desktop\Better-GUIlds-main’

6)Now, go to your Anaconda Prompt or command line and type the following:
cd Desktop
cd Better-GUIlds-main
cd res
dir

7)Then type in “python main.py”

8)This should open our interface

9) This program looks best at 1440x900 on Mac

